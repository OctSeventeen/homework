﻿using Microsoft.Win32;
using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;

namespace Email
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = _Model;
        }

        private MyModel _Model = new MyModel();


        private void CheckRegex(object sender, RoutedEventArgs e)
        {
            string regex = "\\w+@\\w+(?:\\.\\w+){1,3}";
            Regex aRegex = new Regex(regex);
            if (!aRegex.IsMatch(sender.ToString()))
                MessageBox.Show("请输入正确的邮箱格式！");
        }

        private void OnLoad_Executed(object sender, System.Windows.Input.ExecutedRoutedEventArgs e)
        {
            OpenFileDialog aDlg = new OpenFileDialog();
            if (aDlg.ShowDialog() != true) return;
            try
            {
                _Model.Load(aDlg.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void OnLoad_CanExecute(object sender, System.Windows.Input.CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }


        private void OnLoadImage_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            OpenFileDialog aDlg = new OpenFileDialog();
            if (aDlg.ShowDialog() != true) return;
            try
            {
                _Model.LoadImage(aDlg.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void OnLoadImage_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }


        private void OnSendEmail_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("发送成功！");
            Close();
        }

        private void OnSendEmail_CanExecuted(object sender, CanExecuteRoutedEventArgs e)
        {
            if(_Model.ImageContent!=null&& _Model.EmailAddress != null && _Model.EmailContent != null)
                e.CanExecute = true;
        }
    }
}
