﻿using Microsoft.Win32;
using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Imaging;

namespace Email
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            _Model = new MyModel();
            this.DataContext = _Model;
            
        }
        private MyModel _Model;
        int sendButton = 0;

        private void CheckRegex(object sender, RoutedEventArgs e)
        {
            string regex = "\\w+@\\w+(?:\\.\\w+){1,3}";
            Regex aRegex = new Regex(regex);
            if (!aRegex.IsMatch(sender.ToString()))
            {
                MessageBox.Show("请输入正确的邮箱格式！");
                sendButton += 1;
            }
        }

        private void OnLoad_Executed(object sender, System.Windows.Input.ExecutedRoutedEventArgs e)
        {
            OpenFileDialog aDlg = new OpenFileDialog();
            if (aDlg.ShowDialog() != true) return;
            try
            {
                _Model.Load(aDlg.FileName);
                sendButton += 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void OnLoad_CanExecute(object sender, System.Windows.Input.CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void OnLoadImage_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            OpenFileDialog aDlg = new OpenFileDialog();
            if (aDlg.ShowDialog() != true) return;
            try
            {
                _Model.Load(aDlg.FileName);
                sendButton += 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void OnLoadImage_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private string _PictureFile;
        /// <summary>
        ///  
        /// </summary>
        public string PictureFile
        {
            get { return _PictureFile; }
            set
            {
                _PictureFile = value;
                RaisePropertyChanged();
            }
        }

        private void RaisePropertyChanged()
        {
            throw new NotImplementedException();
        }

        private BitmapImage _PictureFileName;

        /// <summary>
        /// =
        /// </summary>
        public BitmapImage PictureFileName
        {
            get { return _PictureFileName; }
            set
            {
                _PictureFileName = value;
                RaisePropertyChanged();
                sendButton += 1;
            }
        }

        private void OnSendEmail_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show(sendButton.ToString());

        }

        private void OnSendEmail_CanExecuted(object sender, CanExecuteRoutedEventArgs e)
        {
            if (sendButton == 3)
                e.CanExecute = true;
        }
    }
}
