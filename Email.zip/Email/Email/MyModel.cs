﻿using System.ComponentModel;
using System.IO;
using System.Text;


namespace Email
{
    class MyModel : INotifyPropertyChanged
    {
        private string _EmailAddress;
        private string _EmailName;
        private string _EmailContent;
        private string _ImageName;
        private byte[] _ImageContent;

        public event PropertyChangedEventHandler PropertyChanged;

        public string EmailAddress { get => _EmailAddress; set => _EmailAddress = value; }

        public string ImageName 
        {
            get { return _ImageName; }
            set
            {
                if (_ImageName == value) return;
                _ImageName = value;
                OnPropertyChanged(nameof(ImageName));
            }
        }

        public byte[] ImageContent 
        {
            get { return _ImageContent; }
            set
            {
                if (_ImageContent == value) return;
                _ImageContent = value;
                OnPropertyChanged(nameof(ImageContent));
            }
        }

        public string EmailContent 
        {
            get { return _EmailContent; }
            set
            {
                if (_EmailContent == value) return;
                _EmailContent = value;
                OnPropertyChanged(nameof(EmailContent));
            }
        }
       
        public string EmailName 
        {
            get { return _EmailName; }
            set
            {
                if (_EmailName == value) return;
                _EmailName = value;
                OnPropertyChanged(nameof(EmailName));
            }
        }

        public void Load(string aFileName)
        {
            string aLines = File.ReadAllText(aFileName, Encoding.UTF8);
            EmailContent = aLines;
            EmailName = aFileName;
        }

        public void LoadImage(string aFileName)
        {
            byte[] aLines = File.ReadAllBytes(aFileName);
            ImageContent = aLines;
            ImageName = aFileName;
        }

        private void OnPropertyChanged(string aPropertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(aPropertyName));
        }


    }
}
